G=[g.*(Mf.*rfx.*cosd(x(1)+x(2))+(ls.*Mf+(-1).*lt.*Mf+Ms.*rs).*sind(x(1))+Mf.*(lt+rfy).*sind(x(1)+x(2)));g.*(Mf.*rfx.*cosd(x(1)+x(2))+Mf.*(lt+rfy).*sind(x(1)+x(2)))];
