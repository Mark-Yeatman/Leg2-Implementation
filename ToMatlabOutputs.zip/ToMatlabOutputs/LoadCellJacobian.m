JC=[lc+lt+(ls+(-1).*lt).*cosd(x(2)),lc+lt;((-1).*ls+lt).*sind(x(2)),0;0,0;0,0;0,0;1,1];
