L=((lt+(ls+(-1).*lt).*cosd(x(1))+la.*cosd(x(1)+x(2))+(-1).*COPfx.*sind(x(1)+x(2))).^2+(COPfx.*cosd(x(1)+x(2))+(ls+(-1).*lt).*sind(x(1))+la.*sind(x(1)+x(2))).^2).^(1/2);
